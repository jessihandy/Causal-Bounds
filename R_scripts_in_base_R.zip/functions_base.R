#' Date created: 14 MAR 2025
#' Date last modified: 14 MAR 2025
#' Purpose: Defines functions needed for point estimation and bounds
#' Functions are defined using base R code only (original functions file uses tidy (dplyr) syntax)

# ---- Base probabilities ----
py1z1 <- function(data){
  #' Pr[Y = 1| Z = 1], i.e. probability of 
  #' suicide given post-policy implementation
  data_z1 = data[data$z == 1, ]
  sum(data_z1$y)/ifelse("n" %in% colnames(data_z1), 
                         sum(data_z1$n), 
                         nrow(data_z1))
}
py1z0 <- function(data){
  #' Pr[Y = 1| Z = 0], i.e. probability of 
  #' suicide given pre-policy 
  data_z0 = data[data$z == 0, ]
  sum(data_z0$y)/ifelse("n" %in% colnames(data_z0), 
                         sum(data_z0$n), 
                         nrow(data_z0))
}
pa1z1 <- function(data){
  #' Pr[A = 1| Z = 1], i.e. probability of being an 
  #' ERPO respondent given post-policy implementation
  data_z1 = data[data$z == 1, ]
  sum(data_z1$a, na.rm = T)/ifelse("n" %in% colnames(data_z1), 
                                    sum(data_z1$n), 
                                    nrow(data_z1))
}
pa0z1 <- function(data){
  #' Pr[A = 1| Z = 1], i.e. probability of not being an 
  #' ERPO respondent given post-policy implementation
  1-pa1z1(data)
}

# ---- Point identifying risk (for joint data setting) ----
py1z1a1 <- function(data){
  #' Pr[Y = 1| Z = 1, A = 1]
  data_z1a1 = data[c(data$z == 1 & data$a >= 1),  ]
  sum(data_z1a1$y, na.rm = T)/nrow(data_z1a1)
}
py1z1a0 <- function(data){
  #' Pr[Y = 1| Z = 1, A = 0]
  data_z1a0 = data[c(data$z == 1 & data$a == 0),  ]
  sum(data_z1a0$y, na.rm = T)/nrow(data_z1a0)
}

# ---- Bounds ----
lb.nt <- function(data){
  ifelse(
    (min(1, 
         py1z1(data)/pa0z1(data),
         py1z0(data)/pa0z1(data))) < 
      (max(0,
           (py1z1(data)-pa1z1(data)) / pa0z1(data), 
           (py1z0(data)-pa1z1(data)) / pa0z1(data))), 
    NA, 
    max(0,
      (py1z1(data)-pa1z1(data)) / pa0z1(data), 
      (py1z0(data)-pa1z1(data)) / pa0z1(data)))
  }
ub.nt <- function(data){
  ifelse(
    (min(1, 
      py1z1(data)/pa0z1(data),
      py1z0(data)/pa0z1(data))) < 
    (max(0,
         (py1z1(data)-pa1z1(data)) / pa0z1(data), 
         (py1z0(data)-pa1z1(data)) / pa0z1(data))), 
    NA, 
    min(1, 
        py1z1(data)/pa0z1(data),
        py1z0(data)/pa0z1(data)))
} 

lb.co <- function(data){
  ifelse(
    (min(1, 
         py1z1(data)/pa1z1(data),
         ((py1z1(data)-py1z0(data))/pa1z1(data))+1)) < 
      (max(0,
           (py1z1(data)-pa0z1(data)) / pa1z1(data), 
           (py1z1(data)-py1z0(data)) / pa1z1(data))),
    NA, 
    (max(0,
         (py1z1(data)-pa0z1(data)) / pa1z1(data), 
         (py1z1(data)-py1z0(data)) / pa1z1(data))))
}
ub.co <- function(data){
  ifelse(
    (min(1, 
         py1z1(data)/pa1z1(data),
         ((py1z1(data)-py1z0(data))/pa1z1(data))+1)) < 
      (max(0,
           (py1z1(data)-pa0z1(data)) / pa1z1(data), 
           (py1z1(data)-py1z0(data)) / pa1z1(data))),
    NA, 
    (min(1, 
         py1z1(data)/pa1z1(data),
         ((py1z1(data)-py1z0(data))/pa1z1(data))+1)))
} 

lb <- function(data){
  ifelse(
    (min(1, 
         py1z1(data)/pa1z1(data),
         ((py1z1(data)-py1z0(data))/pa1z1(data))+1)) < 
      (max(0,
           (py1z1(data)-pa0z1(data)) / pa1z1(data), 
           (py1z1(data)-py1z0(data)) / pa1z1(data))),
    NA, 
    max(0,
        (py1z1(data)-pa0z1(data)) / pa1z1(data), 
        (py1z1(data)-py1z0(data)) / pa1z1(data)))
}
ub <- function(data){
  ifelse(
    (min(1, 
         py1z1(data)/pa1z1(data),
         ((py1z1(data)-py1z0(data))/pa1z1(data))+1)) < 
      (max(0,
           (py1z1(data)-pa0z1(data)) / pa1z1(data), 
           (py1z1(data)-py1z0(data)) / pa1z1(data))), 
    NA, 
    min(1, 
        py1z1(data)/pa1z1(data),
        ((py1z1(data)-py1z0(data))/pa1z1(data))+1))
} 

eff <- function(data){
  ifelse(pa1z1(data)>0,
          (py1z1(data)-py1z0(data))/pa1z1(data),
          NA)
}

t.lb <- function(data){
  lb(data)/ub.nt(data)
}

t.ub <- function(data){
  ub(data)/lb.nt(data)
}